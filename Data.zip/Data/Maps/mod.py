file_list = ['level_5.txt']
numbers = ['1','2','3','4','5','6','7','8','9','0']

for file in file_list:
    f = open(file,'r')
    data = f.read()
    f.close()
    new = ''
    new2 = ''
    for char in data:
        if char == '-':
            char = '='
        new2 += char
    n = 0
    for char in new2:
        if char == '=':
            try:
                if data[n+1] in numbers:
                    char = '-'
            except:
                pass
        new += char
        n += 1
    f = open(file,'w')
    f.write(new)
    f.close()
